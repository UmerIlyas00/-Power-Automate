# Welcome to Power Automate in a day training
This is the Power Automate in a day v9 material (last update : March 2023, by Serge Luca - aka "Doctor Flow")  
- v1 was created in July 2018.  
- v8 Last updated: 03/05/2021
- v9 is being updated by Serge Luca - aka "Doctor Flow" 
- Don't forget to download the resources for the labs, we minimized the number of resource files you need to follow the labs.  
- Some labs require a premium licence, in lab 0 we show you how to create a community license.  
- Don't hesitate to report any typo, error, suggestion in the "issues" part of the site.  
- This is a community project we are volunteers and we do that on our free time.



